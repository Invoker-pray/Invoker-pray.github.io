g++ main.cc -o main && ./main >image.ppm && display image.ppm
